package com.example.olatcpserverscoketapplication.server

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.olatcpserverscoketapplication.R
import kotlinx.coroutines.*
import java.io.*
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean

class TcpServerService : Service() {
    private lateinit var serverJob: Job
    private lateinit var serverScope: CoroutineScope

    private var serverSocket: ServerSocket? = null
   private var socket: Socket? = null

    override fun onBind(intent: Intent): IBinder? {
        return null
    }

    override fun onCreate() {
        super.onCreate()
        Log.e("TcpServerService","onCreate")
        startServer()
    }



    private fun startServer() {
        Log.e("TcpServerService","startServer")
        Thread {
            try {
                serverSocket = ServerSocket(6079) // Replace with your desired port number
                while (true) {
                    socket = serverSocket!!.accept()
                    Log.e("TcpServerService","startServer ")
                    Log.e("TcpServerService","Client connected: ${socket?.inetAddress?.hostAddress}")


                    var dIn = DataInputStream(BufferedInputStream(socket?.getInputStream()));

                    var done:Boolean = false
                    while(!done) {
                        var messageType = dIn.readChar();

                        Log.e("TcpServerService","$messageType ")
                    }

                    dIn.close();


                }
            } catch (e: IOException) {
                e.printStackTrace()
            } finally {
                try {
                    socket?.close()
                    serverSocket?.close()
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }
        }.start()

    }

    private fun stopServer() {
        Log.e("TcpServerService","stopServer")
        serverJob.cancel()
        serverScope.cancel()
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            socket?.close()
            serverSocket?.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }


}
