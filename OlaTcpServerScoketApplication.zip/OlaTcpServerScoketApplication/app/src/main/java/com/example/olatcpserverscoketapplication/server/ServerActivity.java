package com.example.olatcpserverscoketapplication.server;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.olatcpserverscoketapplication.R;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ServerActivity  extends AppCompatActivity implements View.OnClickListener {

    private static final int REQUEST_PICK_FILE = 101;
    private ServerSocket serverSocket;
    private Socket tempClientSocket;
    Thread serverThread = null;
    public static final int SERVER_PORT = 9898;
    private LinearLayout msgList;
    private Handler handler;
    private int greenColor;
    private EditText edMessage;

    private ImageButton mImageButton;
    private ActivityResultLauncher<String> mGetContent;

    public static String TAG= "ServerActivity";
    private List<ClientHandler> clients = new ArrayList<>();
    String filePath;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_server);
        setTitle("Server");
        greenColor = ContextCompat.getColor(this, R.color.teal_700);
        handler = new Handler();
        msgList = findViewById(R.id.msgList);
        edMessage = findViewById(R.id.edMessage);
        mImageButton = findViewById(R.id.file);

        mImageButton.setOnClickListener(this);
        mGetContent = registerForActivityResult(new ActivityResultContracts.GetContent(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri result) {
                        // Handle the selected file here
                        filePath = result.getPath();
                        Log.i("ServerActivity","file Path : " + filePath);
                        // Do something with the file pathedMessage
                        edMessage.setText("File Path : "+filePath);

                    }
                });
        hideSoftKeyboard(this);

    }

    public TextView textView(String message, int color) {
        if (null == message || message.trim().isEmpty()) {
            message = "<Empty Message>";
        }
        TextView tv = new TextView(this);
        tv.setTextColor(color);
        tv.setText(message + " [" + getTime() +"]");
        tv.setTextSize(20);
        tv.setPadding(0, 5, 0, 0);
        return tv;
    }

    public void showMessage(final String message, final int color) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                msgList.addView(textView(message, color));
            }
        });
    }



    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.start_server) {
            msgList.removeAllViews();
            showMessage("Server Started.", Color.BLACK);
            this.serverThread = new Thread(new ServerThread());
            this.serverThread.start();
            return;
        }
        if (view.getId() == R.id.send_data) {
            String msg = edMessage.getText().toString().trim();
            showMessage("Server : " + msg, Color.BLUE);
            closeKeyboard();

            if(filePath.contains("/")){
                Log.i("ServerActivity","Step 1: " + filePath);
                fileSend(filePath);
            }else{
                sendMessage(msg);
            }

        }

        if(view.getId() == R.id.file){
            pickFile();
        }
    }

    private void fileSend(String filePath){
        try {
            if (null != tempClientSocket) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        Log.i("ServerActivity","Step 2: " + filePath);
                        try {
                            Log.i("ServerActivity","Step 3: " + filePath);
                            for (ClientHandler clientHandler : clients) {
                                    clientHandler.fileSend(filePath);
                            }
                        } catch (IOException e) {
                            Log.i("ServerActivity","Step 4 : " + filePath);
                            throw new RuntimeException(e);
                        }


                    }
                }).start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void sendMessage(final String message) {
        try {
            if (null != tempClientSocket) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        PrintWriter out = null;

                                for (ClientHandler clientHandler : clients) {

                                    clientHandler.sendMessage(message);
                                }


                    }
                }).start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    class ServerThread implements Runnable {

        public void run() {
            Socket socket;
            try {
                serverSocket = new ServerSocket(SERVER_PORT);

            } catch (IOException e) {
                e.printStackTrace();
                showMessage("Error Starting Server : " + e.getMessage(), Color.RED);
            }
            if (null != serverSocket) {
                while (!Thread.currentThread().isInterrupted()) {
                    try {
                        Log.i(TAG,"GETTING IP ADDRESS");
                        socket = serverSocket.accept();
                        CommunicationThread commThread = new CommunicationThread(socket);
                        new Thread(commThread).start();
                    } catch (IOException e) {
                        e.printStackTrace();
                        showMessage("Error Communicating to Client :" + e.getMessage(), Color.RED);
                    }
                }
            }
        }
    }

    class CommunicationThread implements Runnable {

        private Socket clientSocket;

        private BufferedReader input;

        public CommunicationThread(Socket clientSocket) {
            this.clientSocket = clientSocket;
            tempClientSocket = clientSocket;

            try {


                this.input = new BufferedReader(new InputStreamReader(this.clientSocket.getInputStream()));

                // Create a new thread to handle communication with the client
                Log.e("SocketApp","Connected devices" + tempClientSocket.getInetAddress());
                ClientHandler clientHandler = new ClientHandler(clientSocket);
                clients.add(clientHandler);
                clientHandler.start();

            } catch (IOException e) {
                e.printStackTrace();
                showMessage("Error Connecting to Client!!", Color.RED);
            }
            showMessage("Connected to Client!!"+tempClientSocket.getInetAddress(), greenColor);
        }

        public void run() {

            while (!Thread.currentThread().isInterrupted()) {
                try {
                    String read = input.readLine();
                    if (null == read || "Disconnect".contentEquals(read)) {
                        Thread.interrupted();
                        read = "Client Disconnected";
                        showMessage("Client : " + read, greenColor);
                        break;
                    }
                    showMessage("Client : " + read, greenColor);
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }

    }

    String getTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        return sdf.format(new Date());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (null != serverThread) {
            sendMessage("Disconnect");
            serverThread.interrupt();
            serverThread = null;
        }
    }

    private static class ClientHandler extends Thread {
        private Socket clientSocket;
      //  private OutputStream outputStream;

        PrintWriter out = null;
        OutputStream file = null;
        byte[] buffer = new byte[4096]; // adjust the buffer size as needed
        int bytesRead;
        public ClientHandler(Socket clientSocket) {
            this.clientSocket = clientSocket;
        }

        @Override
        public void run() {
            try {
                // Get the output stream of the client socket
                out =new PrintWriter(new BufferedWriter(
                        new OutputStreamWriter(clientSocket.getOutputStream())),
                        true);

                file = clientSocket.getOutputStream();
                // Handle incoming messages from the client
                // ...

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void sendMessage(String message) {
            try {
                // Send the message to the client
              //  outputStream.write(message.getBytes());
                out.println(message);
                Log.e("SocketApp","message to client " + message);


            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public void fileSend(String fileName) throws IOException {
            File file = new File(fileName);
            InputStream in = new FileInputStream(file);
            Log.i("ServerActivity","Step 5: " + fileName);
            while ((bytesRead = in.read(buffer)) != -1) {
                out.write(String.valueOf(buffer), 0, bytesRead);
            }
            in.close();
            out.close();
        }
    }
    public static void hideSoftKeyboard(Activity activity) {
        InputMethodManager inputMethodManager =
                (InputMethodManager) activity.getSystemService(
                        Activity.INPUT_METHOD_SERVICE);
        if(inputMethodManager.isAcceptingText()){
            inputMethodManager.hideSoftInputFromWindow(
                    activity.getCurrentFocus().getWindowToken(),
                    0
            );
        }
    }
    private  void closeKeyboard()
    {
        // this will give us the view
        // which is currently focus
        // in this layout
        View view = this.getCurrentFocus();

        // if nothing is currently
        // focus then this will protect
        // the app from crash
        if (view != null) {

            // now assign the system
            // service to InputMethodManager
            InputMethodManager manager
                    = (InputMethodManager)
                    getSystemService(
                            Context.INPUT_METHOD_SERVICE);
            manager
                    .hideSoftInputFromWindow(
                            view.getWindowToken(), 0);
        }
    }


    public void pickFile(){
        mGetContent.launch("*/*");

    }




}